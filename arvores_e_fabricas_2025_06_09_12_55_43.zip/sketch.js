let natureza = [];
let industria = [];

function setup() {
  createCanvas(800, 600);
  noStroke();
}

function draw() {
  background(144, 238, 144);  // Verde claro para o fundo

  // Desenho dos elementos
  for (let i = 0; i < natureza.length; i++) {
    natureza[i].mostrar();
  }

  for (let i = 0; i < industria.length; i++) {
    industria[i].mostrar();
  }

  // Informações sobre as opções
  fill(0);
  textSize(24);
  text("Clique para adicionar árvores (esquerda) ou fábricas (direita)", 20, 30);
  text("Natureza: " + natureza.length + " Árvores", 20, height - 30);
  text("Indústria: " + industria.length + " Fábricas", 20, height - 60);
}

// Função chamada quando o mouse é pressionado
function mousePressed() {
  if (mouseX < width / 2) {
    // Adiciona uma árvore na área verde (lado esquerdo)
    natureza.push(new Elemento(mouseX, mouseY, 'natureza'));
  } else {
    // Adiciona uma fábrica na área industrial (lado direito)
    industria.push(new Elemento(mouseX, mouseY, 'industria'));
  }
}

// Classe para representar os elementos na cidade (árvores ou fábricas)
class Elemento {
  constructor(x, y, tipo) {
    this.x = x;
    this.y = y;
    this.tipo = tipo;
  }

  mostrar() {
    if (this.tipo === 'natureza') {
      fill(34, 139, 34); // Verde para árvores
      ellipse(this.x, this.y, 30, 30); // Representa uma árvore
    } else if (this.tipo === 'industria') {
      fill(169, 169, 169); // Cinza para fábricas
      rect(this.x - 15, this.y - 20, 30, 40); // Representa uma fábrica
    }
  }
}